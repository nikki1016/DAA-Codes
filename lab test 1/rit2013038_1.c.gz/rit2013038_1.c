#include<stdio.h>
#include<time.h>
void heapsort(int [],int ,int);
int partition(int a[],int,int);
void heapsort(int a[],int l,int h) {
	int heap[100000], no, i, j, c, root, temp;
	for (i = l; i <=h; i++) heap[i]=a[i];
        for (i =l+1; i <=h; i++) {
		c = i;
		do
		{
			root = (c - 1) / 2;
			if (heap[root] < heap[c])
			{
				temp = heap[root];
				heap[root] = heap[c];
				heap[c] = temp;
			}
			c = root;
		} while (c != 0);
	}
	for (j = h; j >= l; j--) {
		temp = heap[0];
		heap[0] = heap[j];  
		heap[j] = temp;
		root = 0;
		do
		{
			c = 2 * root + 1;   
			if ((heap[c] < heap[c + 1]) && c < j-1)
			c++;
			if (heap[root]<heap[c] && c<j)    
			{
				temp = heap[root];
				heap[root] = heap[c];
				heap[c] = temp;
			}
			root = c;
		} while (c < j);
	}
         for (i = l; i <=h; i++) a[i]=heap[i];
}
void quicksort(int a[],int low,int high,int key) {
	int tmp;
	if(low<high) {
		tmp=partition(a,low,high);
		if(tmp-low+1<key) {
			heapsort(a,low,tmp-1);
			quicksort(a,tmp+1,high,key);
		}
		else {
			quicksort(a,low,tmp-1,key);
			quicksort(a,tmp+1,high,key);
		}
	}
}
int partition(int a[],int low,int high) {
	int i,j,temp,pivot=a[low];
	i=low;
	j=high;
	pivot=a[low];
	while(i<j) {
		while(a[i]<=pivot) i++;
		while(a[j]>pivot) j--;
		if(i<j) {
			temp=a[j];
			a[j]=a[i];
			a[i]=temp;
		}
		else break;
	}
	a[low]=a[j];
	a[j]=pivot;
	return j;
}
int main() {
	int n,i,j;
	clock_t t1,t2;
	scanf("%d",&n);
	int a[n],b[n];
	int nc[]={2,16,64,128,8192};
	float time;
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
          //     a[i]=rand()%100;
		b[i]=a[i];
	}
	for(i=0;i<5;i++) {
		t1=clock();
		quicksort(a,0,n,nc[i]);
		t2=clock();
		time=t2-t1;
		printf("Time:%9.5f sec\nnc = %d\n",time/CLOCKS_PER_SEC,nc[i]);
		for(j=0;j<n;j++) {
		       printf("%d\n",a[j]);
		       a[j]=b[j];
	        }
	}
	return 0;
}
