#include <cstdio>
#include <cstdlib>
#include <list>
#include <ctime>

using namespace std;

struct node
{
	int value;
	struct node * parent;
	struct node * leftChild;
	struct node * rightChild;
};

struct node * findLastNode(struct node * BinaryHeap, int size)
{
	list<int> Stack;
	
	while (size != 0) {
		if (size & 1) {
			Stack.push_front(true);
		} else {
			Stack.push_front(false);
		}
		
		size = size >> 1;
	}
	
	Stack.pop_front();
	
	struct node * traverse = BinaryHeap;
	bool temp;
	
	while (Stack.size() != 0) {
		temp = Stack.front();
		Stack.pop_front();
		
		if (temp) {
			traverse = traverse->rightChild;
		} else {
			traverse = traverse->leftChild;
		}
	}
	
	return traverse;
}

void bubbleUp(struct node * heap)
{
	if (heap->parent == NULL) {
		return;
	}
	
	if (heap->parent->value < heap->value) {
		int temp = heap->value;
		heap->value = heap->parent->value;
		heap->parent->value = temp;
		
		bubbleUp(heap->parent);
	}
}

struct node * insertUtil(struct node * BinaryHeap, int value, list<bool> * Stack)
{
	bool temp;
	
	if ((*Stack).size() == 1) {
		temp = (*Stack).front();
		(*Stack).pop_front();
		
		if (temp) {
			BinaryHeap->rightChild = (struct node *) calloc(1, sizeof(struct node));
			BinaryHeap->rightChild->parent = BinaryHeap;
			BinaryHeap = BinaryHeap->rightChild;
			BinaryHeap->value = value;
		} else {
			BinaryHeap->leftChild = (struct node *) calloc(1, sizeof(struct node));
			BinaryHeap->leftChild->parent = BinaryHeap;
			BinaryHeap = BinaryHeap->leftChild;
			BinaryHeap->value = value;
		}
	} else {
		temp = (*Stack).front();
		(*Stack).pop_front();
		
		if (temp) {
			BinaryHeap = insertUtil(BinaryHeap->rightChild, value, Stack);
		} else {
			BinaryHeap = insertUtil(BinaryHeap->leftChild, value, Stack);
		}
	}
	
	return BinaryHeap;
}

void insertIntoHeap(struct node * BinaryHeap, int value, list<bool> * Stack)
{
	(*Stack).pop_front();
	
	struct node * newNode = insertUtil(BinaryHeap, value, Stack);
	
	bubbleUp(newNode);
}

struct node * getBinaryHeap(int value)
{
	struct node * BinaryHeap = (struct node *) calloc(1, sizeof(struct node));
	
	BinaryHeap->value = value;
	
	return BinaryHeap;
}

void heapify(struct node * BinaryHeap)
{
	if (BinaryHeap->leftChild != NULL && BinaryHeap->rightChild != NULL) {
		
		if (BinaryHeap->value < BinaryHeap->leftChild->value && BinaryHeap->value < BinaryHeap->rightChild->value) {
			if (BinaryHeap->leftChild->value > BinaryHeap->rightChild->value) {
				
				int temp = BinaryHeap->value;
				BinaryHeap->value = BinaryHeap->leftChild->value;
				BinaryHeap->leftChild->value = temp;
				
				heapify(BinaryHeap->leftChild);
			} else {
				
				int temp = BinaryHeap->value;
				BinaryHeap->value = BinaryHeap->rightChild->value;
				BinaryHeap->rightChild->value = temp;
				
				heapify(BinaryHeap->rightChild);
			}
		} else if (BinaryHeap->value < BinaryHeap->leftChild->value && BinaryHeap->value > BinaryHeap->rightChild->value) {
				
			int temp = BinaryHeap->value;
			BinaryHeap->value = BinaryHeap->leftChild->value;
			BinaryHeap->leftChild->value = temp;
				
			heapify(BinaryHeap->leftChild);
		} else if (BinaryHeap->value > BinaryHeap->leftChild->value && BinaryHeap->value < BinaryHeap->rightChild->value) {
				
			int temp = BinaryHeap->value;
			BinaryHeap->value = BinaryHeap->rightChild->value;
			BinaryHeap->rightChild->value = temp;
				
			heapify(BinaryHeap->rightChild);
		}
	} else if (BinaryHeap->rightChild == NULL && BinaryHeap->leftChild != NULL) {
		
		if (BinaryHeap->leftChild->value > BinaryHeap->value) {
			
			int temp = BinaryHeap->leftChild->value;
			BinaryHeap->leftChild->value = BinaryHeap->value;
			BinaryHeap->value = temp;
		}
		
	}
}

int extractMax(struct node * BinaryHeap, struct node * lastNode)
{
	if (BinaryHeap == NULL) {
		return -1;
	}
	
	if (BinaryHeap == lastNode) {
		
		int max = BinaryHeap->value;
		
		free(BinaryHeap);
		
		return max;
	}
	
	int max = BinaryHeap->value;
	
	int temp = BinaryHeap->value;
	BinaryHeap->value = lastNode->value;
	lastNode->value = temp;
	
	struct node * parent = lastNode->parent;
	
	if (parent->leftChild == lastNode) {
		parent->leftChild = NULL;
	} else {
		parent->rightChild = NULL;
	}
	
	free(lastNode);
	heapify(BinaryHeap);
	
	return max;
}

void heapSort(int arr[], int low, int high)
{
	struct node * BinaryHeap = getBinaryHeap(arr[low]);
	int i, j, HeapSize = 1, temp;
	list<bool> Stack;
	
	for (i = low + 1; i <= high; ++i) {
		++HeapSize;
		
		temp = HeapSize;
		while (temp != 0) {
			if (temp & 1) {
				Stack.push_front(true);
			} else {
				Stack.push_front(false);
			}
			
			temp = temp >> 1;
		}
		
		insertIntoHeap(BinaryHeap, arr[i], &Stack);
	}
	
	struct node * lastNode;
	list<int> SortedList;
	list<int>::iterator itr;
	
	while (HeapSize != 0) {
		lastNode = findLastNode(BinaryHeap, HeapSize);
		SortedList.push_front(extractMax(BinaryHeap, lastNode));
		--HeapSize;
	}
	
	i = low;
	itr = SortedList.begin();
	while (itr != SortedList.end()) {
		arr[i] = *itr;
		++itr;
		++i;
	}
}

void quick_sort(int arr[], int low, int high, int nc)
{
	if (low >= high) {
		return;
	}
	
	int mid = low + ((high - low) / 2);
	
	int temp = arr[mid];
	arr[mid] = arr[high];
	arr[high] = temp;
	
	int pivot = arr[high];
	int i = low;
	int j = high - 1;
	
	while (j >= i) {
		if (arr[j] < pivot && arr[i] > pivot) {
			temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			
			++i;
			--j;
		} else if (arr[j] < pivot && arr[i] < pivot) {
			++i;
		} else if (arr[j] >= pivot && arr[i] >= pivot) {
			--j;
		} else if (arr[j] > pivot && arr[i] < pivot) {
			++i;
			--j;
		} else if (arr[j] == pivot && arr[i] < pivot) {
			--j;
			++i;
		} else if (arr[j] == pivot && arr[i] > pivot) {
			temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			
			++i;
		} else if (arr[j] < pivot && arr[i] == pivot) {
			temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			
			--j;
		} else if (arr[j] > pivot && arr[i] == pivot) {
			--j;
		}
	}
	
	if (i > j) {
		temp = arr[i];
		arr[i] = arr[high];
		arr[high] = temp;
	}
	
	if (i - 1 - low <= nc) {
		heapSort(arr, low, i - 1);
	} else {
		quick_sort(arr, low, i - 1, nc);
	}
	
	if (high - i - 1 <= nc) {
		heapSort(arr, i + 1, high);
	} else {
		quick_sort(arr, i + 1, high, nc);
	}
}

void readInput(int arr[], int n)
{
	int i;
	
	for (i = 0; i < n; ++i) {
		scanf("%d", &arr[i]);
	}
}

void inputRandom(int arr[], int n)
{
	int i;
	
	for (i = 0; i < n; ++i) {
		arr[i] = rand() % 2000;
	}
}

int main()
{
	int n;
	
	scanf("%d", &n);
	// n = 100000;
	int temp, i, HeapSize = 0;
	int nc[] = {2, 16, 64, 128, 8192};
	int arr[n], arr2[n];
	
	// readInput(arr, n);
	inputRandom(arr, n);
	
	for (i = 0; i < n; ++i) {
		arr2[i] = arr[i];
	}
	
	clock_t start_t;
	clock_t stop_t;
	float time_elapsed;
	
	for (i = 0; i < 5; ++i) {
		start_t = clock();
		quick_sort(arr2, 0, n - 1, nc[i]);
		stop_t = clock();
		
		time_elapsed = (float) (stop_t - start_t) / CLOCKS_PER_SEC;
		
		printf("Time: %9.5f sec\n", time_elapsed);
		printf("nc = %d\n", nc[i]);
		
		for (int k = 0; k < n; ++k) {
			printf("%d\n", arr2[k]);
			arr2[k] = arr[k];
		}
		
		//printf("%d %9.5f\n", nc[i], time_elapsed);
	}
	
	return 0;
}
