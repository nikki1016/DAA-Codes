#include <stdio.h>
#include <time.h>
int partition(int a[],int l,int h) {
	int x,i,j,k;
	x = a[h-1];
	i = l-1;
	for (j = l; j < h; j++) {
		if (a[j] <= x) {
			i++;
			k = a[i];
			a[i] = a[j];
			a[j] = k;
		}
	}
	k = a[i+1];
	a[i+1] = a[h];
	a[h] = k;
	return i+1;
}
void heap(int a[], int l, int h) {
	int n,i,j,k,c;
	int b[h-l];
	if(l < h) {
		j = 1;
		for(i = l; i < h-1; i++) {
			if(j == 1) {
				b[j] = a[i];
				j++;
			} else {
				if(j%2 == 0) {
					if(b[j/2] >= b[j]) {
						k = b[j/2];
						b[j/2] = b[j];
						b[j] = k;
					}
				} else {
					if(b[j/2] >= b[j]) {
						k = b[j/2];
						b[j/2] = b[j];
						b[j] = k;
					}
				}
				j++;
			}
		}
		c = h-l;
		i = l;
		while(c--) {
			k = b[1];
			b[c] = b[1];
			b[1] = k;
			a[i] = b[c];
			for(j = c-2; j >= 1;j = j-2) {
				if(b[j] < b[j+1]) {
					k = b[j/2];
					b[j/2] = b[j];
					b[j] = k;
				} else if(b[j] > b[j+1]) {
					k = b[j/2];
					b[j/2] = b[j+1];
					b[j+1] = k;
				}
			}

		}
		i++;
	}
}


void hybrid_sort(int a[], int l, int h,int nc) {
	int p;
	if (l < h) {
		p = partition(a,l,h);
		if (p-l-1 <= nc) {
			heap(a,l,p-1);
		} else hybrid_sort(a,l,p-1,nc);
		if (h-p <= nc) {
			heap(a,p+1,h);
		} else hybrid_sort(a,p+1,h,nc);
	}
}
int main() {
	int n,i,k;
	int A[200000];
	int nc[] = {2, 16, 64, 128, 8192};
	clock_t strt_t;
	clock_t stop_t;
	float tm;
	scanf("%d", &n);
	for(i = 0; i < n; i++) {
		scanf("%d", &A[i]);
	}
	for(i = 0; i < 5; i++) {
		strt_t = clock();
		hybrid_sort(A,0,n,nc[i]);
		stop_t = clock();

		tm = (float)(stop_t - strt_t)/CLOCKS_PER_SEC;

		printf("Time: %9.5f sec\n", tm);
		printf("nc = %d\n", nc[i]);

		for(k = 0; k < n; k++) {
			printf("%d\n", A[k]);
		}
	}
	return 0;
}

