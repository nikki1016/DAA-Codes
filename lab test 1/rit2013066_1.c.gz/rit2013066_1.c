#include <stdio.h>
#include <time.h>
#include <stdlib.h>

typedef struct nod {
	int num;
	struct nod* parent;
	struct nod* left;
	struct nod* right;
} node;

node* insert(node* head, int n, int a)
{
	node* tmp = (node*) malloc(sizeof (node));
	tmp->num = a;
	tmp->left = NULL;
	tmp->right = NULL;

	if (n == 1) {
		tmp->parent = NULL;
		return tmp;
	}

	node *hd = head;
	int m = n >> 1;
	int bit = 1;
	while (m >>= 1)
		bit <<= 1;

	while (bit != 1) {
		if (n & bit) {
			hd = hd->right;
		} else {
			hd = hd->left;
		}
		bit >>= 1;
	}

	tmp->parent = hd;
	if (n & bit) {
		hd->right = tmp;
	} else {
		hd->left = tmp;
	}

	while (tmp->parent != NULL && tmp->parent->num < tmp->num) {
		int tp = tmp->parent->num;
		tmp->parent->num = tmp->num;
		tmp->num = tp;
		tmp = tmp->parent;
	}

	return head;
}

int del(node* head, int n)
{
	int a = head->num;
	if (n == 1) {
		free(head);
		head = NULL;
		return a;
	}

	node *hd = head;
	int m = n >> 1;
	int bit = 1;
	while (m >>= 1)
		bit <<= 1;
	while (bit != 1) {
		if (n & bit) {
			hd = hd->right;
		} else {
			hd = hd->left;
		}
		bit >>= 1;
	}
	if (n & bit) {
		head->num = hd->right->num;
		free(hd->right);
		hd->right = NULL;
	} else {
		head->num = hd->left->num;
		free(hd->left);
		hd->left = NULL;
	}

	hd = head;
	while (hd->left != NULL) {
		if (hd->right != NULL && hd->right->num > hd->left->num) {
			if (hd->right->num > hd->num) {
				int tp = hd->right->num;
				hd->right->num = hd->num;
				hd->num = tp;
				hd = hd->right;
			} else {
				break;
			}
		} else {
			if (hd->left->num > hd->num) {
				int tp = hd->left->num;
				hd->left->num = hd->num;
				hd->num = tp;
				hd = hd->left;
			} else {
				break;
			}
		}
	}

	return a;
}

void heap(int arr[], int n)
{
	if (n == 0 || n == 1) {
		return;
	}

	int i;
	node* head = NULL;
	for (i = 0; i < n; i++)
		head = insert(head, i + 1, arr[i]);

	for (i = 0; i < n; i++)
		arr[n - i - 1] = del(head, n - i);
	
	return;
}

int partition(int arr[], int l, int h)
{
	int x = arr[h];
	int i = l - 1;
	int j;

	for (j = l; j < h; j++) {
		if (arr[j] <= x) {
			i++;
			int tmp = arr[i];
			arr[i] = arr[j];
			arr[j] = tmp;
		}
	}
	int tmp = arr[i + 1];
	arr[i + 1] = arr[h];
	arr[h] = tmp;

	return (i + 1);
}


void quick(int arr[], int l, int r, int k)
{
	int pivot = partition(arr, l, r);

	if ((pivot - l) < k)
		heap(&arr[l], pivot - l);
	else
		quick(arr, l, pivot - 1, k);
	if ((r - pivot) < k)
		heap(&arr[pivot + 1], r - pivot);
	else
		quick(arr, pivot + 1, r, k);

	return;
}

int read_input(int A[])
{
	int n, i;
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		scanf("%d", &A[i]);
	//	A[i] = rand();
	}

	return n;
}

int main()
{
	int n, i, k;
	int A[200000];
	int B[200000];
	int nc[] = {2, 16, 64, 128, 8192};

	clock_t strt_t;
	clock_t stop_t;
	float tm;

	n = read_input(A);

	for (i = 0; i < 5; i++) {
		strt_t = clock();

		for (k = 0; k < n; k++)
			B[k] = A[k];

		quick(B, 0, n - 1, nc[i]);
		stop_t = clock();

		tm = (float) (stop_t - strt_t) / CLOCKS_PER_SEC;

		printf("Time: %9.5f sec\n", tm);
		printf("nc = %d\n", nc[i]);

		for (k = 0; k < n; k++) {
			printf("%d\n", B[k]);
		}
	}

	return 0;
}
