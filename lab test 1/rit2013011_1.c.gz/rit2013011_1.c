#include <stdio.h>
#include <math.h>
#include <time.h>
int a[100000];
clock_t end,beg;
double ts;
int n;
void quick(int a[], int low, int up,int x);
int partition(int a[], int low, int up);
int left(int i);
int right(int i);
int parent(int i);
void max_heapify(int a[],int i,int j);
void build_max_heap(int a[],int j);
void heapsort(int a[],int j);
int temp[100000];

int main() {
	clock_t strt_t;
	clock_t stop_t;
	float tm;
	int i,x,j;
	time_t t;
	srand((unsigned)(&t));
	int y = 1;
	int nc[] = {2,16,64,128,8192};
	scanf("%d",&n);	
	if(y = 1) {
		for(i = 0; i < n; i++) {
			scanf("%d",&a[i]);
		}
		for(i = 0; i < 5; i++) {
			strt_t = clock();
			quick(a,0,n-1,nc[i]);
			stop_t = clock();
			tm = (float)(stop_t - strt_t)/CLOCKS_PER_SEC;
			printf("Time: %9.5f sec\n", tm);
			printf("nc = %d\n", nc[i]);
			for(j = 0; j < n; j++) {
				printf("%d\n",a[j]);

			}
		}
	}
	/*else {
	  for(i = 0; i < 5; i++) {
	  for (i = 0; i < n; i++) {
	  a[i] = rand()%10000;
	  }
	  beg = clock();
	  quick(a, 0, n-1,x);
	  end = clock();
	  ts = (double)(end-beg);
	  printf("%d %lf\n",x,ts);

	  }
	  }*/


	return 0;
}

void quick(int a[], int low, int up,int x) {

	int pivloc;
	if(low >= up)
		return;
	pivloc = partition(a, low, up);
	if((pivloc-low-1) > x)
		quick(a, low, pivloc-1,x);
	else {	
		int tmp[pivloc-low];
		int i,j=0;
		for(i = low; i <= pivloc-1; i++) 
			tmp[j++] = a[i]; 
		heapsort(tmp,j);
	}
	if((up-pivloc-1) > x)
		quick(a, pivloc+1,up,x);
	else {
	        int tmp[up-pivloc];
                int i,j=0;
		for(i = pivloc+1; i <= up; i++)
			tmp[j++] = a[i];
		heapsort(tmp,j);
	}
}


int partition(int a[], int low, int up) {

	int i, j, pivot, t;
	i = low+1;
	j = up;
	pivot = a[low];
	while (i <= j) {
		while ((a[i] < pivot) && (i < up))
			i++;
		while (a[j] > pivot) 
			j--;
		if (i < j) {
			t = a[i];
			a[i] = a[j];
			a[j] = t;
			i++;
			j--;
		}
		else 
			i++;
	}
	a[low] = a[j];
	a[j] = pivot;
	return j;
}

int left(int i) {
	return (2*i);
}

int right(int i) {
	return (2*i + 1);
}

int parent(int i) {
	return (i/2);
}

void max_heapify(int a[], int i, int j) {
	int l = left(i);
	int r = right(i);
	int largest;
	int x;
	if(l <= j && a[l] > a[i])
		largest = l;
	else
		largest = i;
	if(r <= j && a[r] > a[largest])
		largest = r;
	if(largest != i) {
		x = a[largest];
		a[largest] = a[i];
		a[i] = x;
		max_heapify(a, largest, j);
	}
}

void build_max_heap(int a[], int j) {
	int i;
	for(i = j/2; i >= 1; i--) {
		max_heapify(a, i, j);
	}
}

void heapsort(int a[],int j) {
	int x,i;
	for(i = j; i >= 2; i--) {
		x = a[1];
		a[1] = a[i];
		a[i] = x;
		n--;
		max_heapify(a, 1,j);
	}
}

