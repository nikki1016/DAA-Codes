#include<stdio.h>
#include<stdlib.h>
#include <time.h>

void quick(int a[], int low, int up, int nc);
int partition(int a[], int low, int up);
void heapSort(int a[], int l, int h);

void hybrid_sort(int a[], int n, int nc) {
	if(n < nc) {
		heapSort(a, 0, n-1);
	} else {
		quick(a, 0, n-1, nc);
	}

}

void quick(int a[], int low, int up, int nc) {
	int pivloc;
	if (low >= up)
		return;

	pivloc = partition(a,low, up);

	if(pivloc-low < nc) {
		heapSort(a, low, pivloc-1);
	//	return;
	}else {
		quick(a, low, pivloc-1, nc);
	}
	if(up-pivloc < nc) {
		heapSort(a, pivloc+1, up);
	} else {
		quick(a,pivloc+1,up,nc);
	}
}

int partition(int a[], int low, int up) {
	int pivot;
	pivot = a[low];
//	printf("%d\n",pivot);
	int i,j,k;
	i = low+1;
	j = up;
	
	while(i <= j) {
		while((a[i] < pivot) && (i < up))
		i++;
		while(a[j] > pivot)
		j--;
		if (i < j) {
			k = a[i];
			a[i] = a[j];
			a[j] = k;
			i++;
			j--;
		}
		else
		i++;
	}
	a[low] = a[j];
	a[j] = pivot;
	return j;
}
/*void quick(int a[], int low, int up,int x,int n);
int partition(int a[], int low, int up);
int main() {
	int n;
	printf("enter n\n");
	scanf("%d",&n);
	int a[n],i;
	printf("enter elements\n");
	for (i = 0; i < n; i++) {
		scanf("%d",&a[i]);
		
	}
	int x;
	printf("enter the kth index\n");
	scanf("%d",&x);
	
	quick(a,0,n-1,x,n);
//	for (i = 0; i < n; i++)
//	printf("%d ",a[i]);
//	printf("\n");
	return 0;
}
void quick(int a[], int low, int up,int x,int n) {
	int pivloc;
	if (low > up)
	return;
	else if(low==up&&low==x-1) {
		printf("%d smallest element is %d\n",x,a[low]);
		return;
	}
//	printf("%d\n",x-1);
	pivloc = partition(a,low,up);
//	printf("%d\n",a[pivloc]);
	//if ((n-x) == pivloc) {
	if((x-1) == pivloc) {
	printf("%d smallest elemnt is %d\n",x,a[pivloc]);
	return;
}
//	if ((up-(x-1)) == pivloc) {
//		printf("%d\n",a[pivloc]);
//		return;
//	}
	
	quick(a,low,pivloc-1,x,n);
	quick(a,pivloc+1,up,x,n);
}
int partition(int a[], int low, int up) {
	int pivot;
	pivot = a[low];
//	printf("%d\n",pivot);
	int i,j,k;
	i = low+1;
	j = up;
	
	while(i <= j) {
		while((a[i] < pivot) && (i < up))
		i++;
		while(a[j] > pivot)
		j--;
		if (i < j) {
			k = a[i];
			a[i] = a[j];
			a[j] = k;
			i++;
			j--;
		}
		else
		i++;
	}
	a[low] = a[j];
	a[j] = pivot;
	return j;
}*/
struct node{
	int val;
	struct node *left;
	struct node *right;
	struct node *par;	
};

void max_heap(struct node *par){
	if(par == NULL){
		return;
	}
	int swap,d=0;
	if(par->left != NULL && par->left->val > par->val){
		swap=par->left->val;
		par->left->val=par->val;
		par->val=swap;
		d=1;
	}
	if(par->right != NULL && par->right->val > par->val){
		swap=par->right->val;
		par->right->val=par->val;
		par->val=swap;
		d=1;
	}
	if(d == 1){
		max_heap(par->par);
	}
//	return root;
}

void max_dlte(struct node *ptr){
	int x,y,l,r,largest;
	
	if( ptr->left==NULL && ptr->right== NULL){
		return;
	}
	else if(ptr->right == NULL){
		if(ptr->left->val > ptr->val){
//		printf("hii  %d\n",ptr->val);
		x=ptr->left->val;
		ptr->left->val=ptr->val;
		ptr->val=x;
		max_dlte(ptr->left);
	}else{
		return;
	}
	}else{
		largest=y;
	l=ptr->left->val;
	r=ptr->right->val;
	y=ptr->val;
	if(l > y && r < y){
		x=l;
		l=y;
		y=x;
		largest=l;
	}else if(l < y && r > y){
		x=r;
		r=y;
		y=x;
		largest=r;
	}else if(l > y && r >y){
		if(l>r){
			x=l;
			l=y;
			y=x;
			largest=l;
		}else{
			x=r;
			r=y;
			y=x;
			largest=r;
		}
	}

	ptr->left->val=l;
	ptr->right->val=r;
	ptr->val=y;
	if(largest==l)
	max_dlte(ptr->left);
	else if(largest==r)
	max_dlte(ptr->right);
	else 
	return;
}
}

struct node *ins(struct node *root,int item,int c){
	struct node *temp, *ptr, *pred;
	int i,j;
	temp = (struct node *)malloc(sizeof(struct node));
	temp->val = item;
	temp->left = NULL;
	temp->right = NULL;

	if(c==1){
		temp->par = NULL;
		root=temp;
	}else{
		ptr=root;
		for(i=31;i>=0;i--){
			if((c >> i) & 1){
				break;
			}
			}for(j=i-1;j>=0;j--){
				if((c>>j) & 1){
					pred=ptr;
										
					ptr = ptr->right;
				}else{
					pred=ptr;
					ptr = ptr->left;
				}
			}
		if(ptr == pred->left){
			pred->left=temp;
		}else{
			pred->right=temp;
		}
		temp->par=pred;				
	}
	max_heap(temp->par);
	return root;
}

void inordr(struct node *root){
	struct node *ptr;
	ptr = root;
	if(ptr==NULL){
		return;
	}
	inordr(ptr->left);
	printf("%d ",ptr->val);
	inordr(ptr->right);
}

int dlte(struct node *root,int c){
	int i,j;		
	struct node *temp, *ptr, *pred;
	ptr= root;
	if(c==1){
		int k;
		k = root->val;
		root=NULL;
		return k;
	}else{
		for(i=31;i>=0;i--){
			if((c >> i) & 1){
				break;
			}
		}for(j=i-1;j>=0;j--){
			if((c >> j) & 1){
				ptr = ptr->right;
			}else{
				ptr = ptr->left;
			}		
		}
//		printf("%d",ptr->val);			
		root->val = ptr->val;
		if(ptr==ptr->par->right)
		ptr->par->right=NULL;
		else
		ptr->par->left=NULL;				
	/*	if(root->right == NULL){
		printf("hhhh");
		}*/
		max_dlte(root);	
	}	
	return (root->val);
}

void heapSort(int a[], int l, int h) {
	int i,  num, c;
	int aux[h-l+1];

	struct node *root;
	c=0;
	for(i=l;i<=h;i++) {
		aux[i-l] = a[l];
		c++;
		root = ins(root, a[l], c);
	//	c++;
	}
	for(i=h;i>=l;i--) {
		a[h] = dlte(root, c);
		c--;
	}

}

int main() {
	int n;
	int a[200000];
	int b[200000];

	int nc[] = {2, 16, 64, 128, 8192};
	clock_t strt_t;
	clock_t stop_t;
	float tm;

	int i;
	/*n = 100000;
	for(i=0;i<100000;i++) {
		a[i] = 100000-i;
		b[i] = a[i];	
	}
*/
	scanf("%d", &n);
	for(i=0;i<n;i++) {
		scanf("%d", &a[i]);
		b[i] = a[i];
	}
	for(i=0;i<5;i++) {
//		strt_t = clock();
		if(i!=0) {
			int j;
			for(j=0;j<n;j++) {
				a[j] = b[j];
			}
		}
		strt_t = clock();
		hybrid_sort(a, n, nc[i]);
		stop_t = clock();

		tm = (float) (stop_t - strt_t)/CLOCKS_PER_SEC;

		printf("%d  %9.5f\n", nc[i], tm);
		int k;
		for(k=0;k<n;i++) {
			printf("%d\n", a[k]);
		}
	}

	return 0;
}
